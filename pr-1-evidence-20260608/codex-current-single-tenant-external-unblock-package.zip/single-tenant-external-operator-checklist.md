# X-Agent Single-Tenant External Operator Checklist

- Status: `blocked`
- OK: `true`
- Release ready: `false`
- Release claim allowed: `false`
- Source handoff: `.xagent_runtime/reports/single-tenant-external-release-freeze-handoff.json`
- Release claim aggregation: `.xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json`
- Items: `1`
- Required env vars: `18`
- Required CLI args: `1`
- Provider env contracts: `0`
- Commands: `2`

## Operator Inputs

- `k8s_namespace`: `<namespace>`
- `release_pr_url`: `XAGENT_REMOTE_PR_URL`
- `release_ci_url`: `XAGENT_REMOTE_CI_URL`
- `release_ci_status`: `XAGENT_REMOTE_CI_STATUS`
- `release_artifacts_url`: `XAGENT_REMOTE_ARTIFACTS_URL`

## Provider Environment Contracts

- None

## Release Claim Guard

- Status: `failed`
- Loaded: `true`
- Fresh: `false`
- Release claim allowed: `false`
- Summary: Release-claim aggregation is missing or older than the source release-freeze handoff.
- Root cause groups: `0`
- Root cause blockers: `0`

### Root Cause Groups

- None

## Strict Execution Order

1. `release_environment_preflight` - Run release environment preflight: `python scripts/check_release_environment_preflight.py --strict --output .xagent_runtime/reports/release-environment-preflight.json`
   Acceptance: Preflight has no blocked checks before strict external execution continues.
2. `local_structural_refresh` - Regenerate local handoff artifacts: `python scripts/run_single_tenant_external_local_refresh.py --timeout-seconds 180`
   Acceptance: Release-freeze handoff, operator checklist, evidence pack, and receipt template are fresh.
3. `operator_rehearsal_maps` - Materialize operator rehearsal maps: `python scripts/build_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps.json`
   Acceptance: Blank remote URL and digest maps are created only when outputs do not already exist.
4. `execution_receipt_assist_plan` - Review execution receipt assist plan: `python scripts/assist_single_tenant_external_execution_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --output .xagent_runtime/reports/single-tenant-external-execution-receipt-assist.json`
   Acceptance: Plan-only assist records receipt_sha256_before and does not write the receipt.
5. `execute_write_guard` - Hold execute and receipt writes until external inputs are real: `manual gate: do not use --execute, --write-receipt, or --mark-passed-from-exit-zero`
   Acceptance: Provider credentials, PR/CI URLs, artifact URLs, observability env, and KUBECONFIG are real.
6. `external_artifact_url_policy` - Verify external artifact URLs before claiming release readiness: `manual gate: verify every required artifact URL is external HTTPS and credential-free; collect remote SHA-256 for each artifact`
   Acceptance: Every required artifact URL is external HTTPS, non-placeholder, credential-free, and has remote_artifact_sha256_observed matching expected_sha256.
7. `operator_rehearsal_maps_check` - Check filled operator rehearsal maps: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
   Acceptance: Filled remote URL and digest maps pass before the strict operator rehearsal gate runs.
8. `operator_rehearsal_gate` - Run strict operator rehearsal gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
   Acceptance: Strict operator rehearsal passes with filled --remote-url-map and --remote-digest-map before receipt write mode is used.
9. `execution_receipt_assist_write` - Write receipt from real external evidence: `python scripts/assist_single_tenant_external_execution_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --output .xagent_runtime/reports/single-tenant-external-execution-receipt-assist.json --operator-rehearsal-gate .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json --remote-delivery-handoff .xagent_runtime/reports/remote-delivery-handoff.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --execute --write-receipt --mark-passed-from-exit-zero`
   Acceptance: --write-receipt updates the receipt only after real commands, artifacts, local hashes, --remote-url-map URLs, remote_artifact_sha256_observed values, and --remote-digest-map proof values pass.
10. `receipt_digest_verification` - Verify receipt digest transition: `manual gate: compare receipt_sha256_before and receipt_sha256_after against receipt files`
   Acceptance: receipt_sha256_after matches the actual written receipt file after --write-receipt.
11. `execution_receipt_require_complete` - Require complete execution receipt: `python scripts/check_single_tenant_external_execution_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --require-complete`
   Acceptance: Execution receipt checker passes with --require-complete.
12. `release_claim_require_ready` - Require ready release claim: `python scripts/check_single_tenant_external_release_claim_aggregation.py --reports-dir .xagent_runtime/reports --output .xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json --require-ready`
   Acceptance: Release-claim aggregation checker passes with --require-ready.

## Required Env Vars

- `OPENAI_API_KEY`
- `OPENAI_BASE_URL`
- `OPENAI_MODEL`
- `XAGENT_REMOTE_PR_URL`
- `XAGENT_REMOTE_CI_URL`
- `XAGENT_REMOTE_CI_STATUS`
- `XAGENT_REMOTE_ARTIFACTS_URL`
- `XAGENT_SECURITY_MODE`
- `XAGENT_DEPLOYMENT_ENVIRONMENT`
- `XAGENT_AUDIT_HMAC_SECRET`
- `KUBECONFIG`
- `XAGENT_WORKFLOW_EVENT_BROKER_BACKEND`
- `XAGENT_LANGFUSE_PUBLIC_KEY`
- `XAGENT_LANGFUSE_SECRET_KEY`
- `XAGENT_LANGFUSE_HOST`
- `XAGENT_SENTRY_DSN`
- `XAGENT_SENTRY_ENVIRONMENT`
- `XAGENT_SENTRY_TRACES_SAMPLE_RATE`

## Required CLI Args

- `--k8s-namespace`

## Operator Checklist

### Checklist 1. Pass final release-claim aggregation guard

- Blocker: `single_tenant_external_release_claim_aggregation`
- Status: `failed`
- Summary: Release-claim aggregation is missing or older than the source release-freeze handoff.

Env to provide:
- `OPENAI_API_KEY`
- `OPENAI_BASE_URL`
- `OPENAI_MODEL`
- `XAGENT_REMOTE_PR_URL`
- `XAGENT_REMOTE_CI_URL`
- `XAGENT_REMOTE_CI_STATUS`
- `XAGENT_REMOTE_ARTIFACTS_URL`
- `XAGENT_SECURITY_MODE`
- `XAGENT_DEPLOYMENT_ENVIRONMENT`
- `XAGENT_AUDIT_HMAC_SECRET`
- `KUBECONFIG`
- `XAGENT_WORKFLOW_EVENT_BROKER_BACKEND`
- `XAGENT_LANGFUSE_PUBLIC_KEY`
- `XAGENT_LANGFUSE_SECRET_KEY`
- `XAGENT_LANGFUSE_HOST`
- `XAGENT_SENTRY_DSN`
- `XAGENT_SENTRY_ENVIRONMENT`
- `XAGENT_SENTRY_TRACES_SAMPLE_RATE`

CLI args to provide:
- `--k8s-namespace`

Provider env contracts:
- None

Commands to run:
- `python scripts/check_single_tenant_external_execution_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --output .xagent_runtime/reports/single-tenant-external-execution-receipt-contract.json --require-complete`
- `python scripts/check_single_tenant_external_release_claim_aggregation.py --reports-dir .xagent_runtime/reports --output .xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json --require-ready`

Expected artifacts:
- `.xagent_runtime/reports/single-tenant-external-execution-receipt-contract.json`
- `.xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json`

Acceptance:
- External execution receipt checker passes with --require-complete.
- Release-claim aggregation checker passes with --require-ready and release_claim_allowed=true.

Next actions:
- Fix missing, invalid, stale, or contradictory release-claim reports before handoff.

## Overall Next Actions

- Run the strict external release runner and archive the delivery receipt, PR/CI manifest, upload bundle index, readiness checklist, PR/CI upload handoff, delivery status report, evidence collection pack, execution receipt, and final handoff artifact index.
- Fix missing, invalid, stale, or contradictory release-claim reports before handoff.
