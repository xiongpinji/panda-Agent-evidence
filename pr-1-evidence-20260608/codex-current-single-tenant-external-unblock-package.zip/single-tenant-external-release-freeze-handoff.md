# X-Agent Single-Tenant External Release-Freeze Handoff

- Status: `ready`
- OK: `true`
- Release ready: `true`
- Plan: `.xagent_runtime/reports/single-tenant-external-unblock-plan.json`
- Audit: `.xagent_runtime/reports/single-tenant-external-release-audit.json`
- Required env vars: `0`
- Required CLI args: `0`
- Provider env contracts: `0`
- Commands: `19`
- Expected artifacts: `34`

## Operator Inputs

- `k8s_namespace`: `<namespace>`
- `release_pr_url`: `XAGENT_REMOTE_PR_URL`
- `release_ci_url`: `XAGENT_REMOTE_CI_URL`
- `release_ci_status`: `XAGENT_REMOTE_CI_STATUS`
- `release_artifacts_url`: `XAGENT_REMOTE_ARTIFACTS_URL`

## Root Cause Summary

- None

## Operator Checklist

No external release blockers remain.

## Provider Environment Contracts

- None

## Env Matrix

- None

## Command Sequence

1. `python scripts/run_single_tenant_external_release_strict.py --strict --k8s-namespace <namespace> --output .xagent_runtime/reports/single-tenant-external-release-strict-run.json`
2. `python scripts/check_single_tenant_external_release_strict_run.py --report .xagent_runtime/reports/single-tenant-external-release-strict-run.json --output .xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json --require-ready`
3. `python scripts/check_single_tenant_external_handoff_artifacts.py --require-ready --strict-run-report .xagent_runtime/reports/single-tenant-external-release-strict-run.json --strict-run-contract .xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json --output .xagent_runtime/reports/single-tenant-external-handoff-artifacts.json`
4. `python scripts/build_single_tenant_external_delivery_receipt.py --handoff-artifacts .xagent_runtime/reports/single-tenant-external-handoff-artifacts.json --strict-run-contract .xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json --remote-handoff .xagent_runtime/reports/remote-delivery-handoff.json --output .xagent_runtime/reports/single-tenant-external-delivery-receipt.json`
5. `python scripts/check_single_tenant_external_delivery_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-delivery-receipt.json --handoff-artifacts .xagent_runtime/reports/single-tenant-external-handoff-artifacts.json --strict-run-contract .xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json --remote-handoff .xagent_runtime/reports/remote-delivery-handoff.json --output .xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json --require-ready`
6. `python scripts/build_single_tenant_external_pr_ci_evidence_manifest.py --receipt .xagent_runtime/reports/single-tenant-external-delivery-receipt.json --receipt-contract .xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json --output .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json`
7. `python scripts/check_single_tenant_external_pr_ci_evidence_manifest.py --manifest .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json --receipt .xagent_runtime/reports/single-tenant-external-delivery-receipt.json --receipt-contract .xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json --output .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json --require-ready`
8. `python scripts/build_single_tenant_external_upload_bundle_index.py --pr-ci-manifest .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json --pr-ci-contract .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json --output .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json`
9. `python scripts/check_single_tenant_external_upload_bundle_index.py --index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --pr-ci-manifest .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json --pr-ci-contract .xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json --output .xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json --require-ready`
10. `python scripts/build_single_tenant_external_readiness_execution_checklist.py --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --upload-contract .xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json --output .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json`
11. `python scripts/check_single_tenant_external_readiness_execution_checklist.py --checklist .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --upload-contract .xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json --output .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist-contract.json --require-ready`
12. `python scripts/build_single_tenant_external_pr_ci_upload_handoff.py --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --upload-contract .xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json --readiness-checklist .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json --output .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.json --markdown-output .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.md`
13. `python scripts/check_single_tenant_external_pr_ci_upload_handoff.py --handoff .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.json --markdown .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.md --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --upload-contract .xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json --readiness-checklist .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json --output .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff-contract.json --require-ready`
14. `python scripts/build_single_tenant_external_delivery_status_report.py --output .xagent_runtime/reports/single-tenant-external-delivery-status-report.json --markdown-output .xagent_runtime/reports/single-tenant-external-delivery-status-report.md`
15. `python scripts/check_single_tenant_external_delivery_status_report.py --report .xagent_runtime/reports/single-tenant-external-delivery-status-report.json --markdown .xagent_runtime/reports/single-tenant-external-delivery-status-report.md --output .xagent_runtime/reports/single-tenant-external-delivery-status-report-contract.json --require-ready`
16. `python scripts/build_single_tenant_external_evidence_collection_pack.py --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --readiness-checklist .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json --upload-handoff .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.json --delivery-status-report .xagent_runtime/reports/single-tenant-external-delivery-status-report.json --output .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --markdown-output .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.md`
17. `python scripts/check_single_tenant_external_evidence_collection_pack.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --markdown .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.md --upload-index .xagent_runtime/reports/single-tenant-external-upload-bundle-index.json --readiness-checklist .xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json --upload-handoff .xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.json --delivery-status-report .xagent_runtime/reports/single-tenant-external-delivery-status-report.json --output .xagent_runtime/reports/single-tenant-external-evidence-collection-pack-contract.json --require-ready`
18. `python scripts/check_single_tenant_external_execution_receipt.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --output .xagent_runtime/reports/single-tenant-external-execution-receipt-contract.json --require-complete`
19. `python scripts/check_single_tenant_external_release_claim_aggregation.py --reports-dir .xagent_runtime/reports --output .xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json --require-ready`

## Expected Artifacts

- `.xagent_runtime/reports/single-tenant-external-release-audit.json`
- `.xagent_runtime/reports/single-tenant-external-unblock-plan.json`
- `.xagent_runtime/reports/single-tenant-external-unblock-plan.md`
- `.xagent_runtime/reports/single-tenant-external-unblock.env.example`
- `.xagent_runtime/reports/single-tenant-external-release-freeze-handoff.json`
- `.xagent_runtime/reports/single-tenant-external-release-freeze-handoff.md`
- `.xagent_runtime/reports/single-tenant-external-release-freeze.env.example`
- `.xagent_runtime/reports/single-tenant-external-release-freeze-handoff-contract.json`
- `.xagent_runtime/reports/single-tenant-external-unblock-package.zip`
- `.xagent_runtime/reports/single-tenant-external-unblock-package-report.json`
- `.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json`
- `.xagent_runtime/reports/single-tenant-external-release-strict-run.json`
- `.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json`
- `.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json`
- `.xagent_runtime/reports/single-tenant-external-delivery-receipt.json`
- `.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json`
- `.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json`
- `.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json`
- `.xagent_runtime/reports/single-tenant-external-upload-bundle-index.json`
- `.xagent_runtime/reports/single-tenant-external-upload-bundle-index-contract.json`
- `.xagent_runtime/reports/single-tenant-external-readiness-execution-checklist.json`
- `.xagent_runtime/reports/single-tenant-external-readiness-execution-checklist-contract.json`
- `.xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.json`
- `.xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff.md`
- `.xagent_runtime/reports/single-tenant-external-pr-ci-upload-handoff-contract.json`
- `.xagent_runtime/reports/single-tenant-external-delivery-status-report.json`
- `.xagent_runtime/reports/single-tenant-external-delivery-status-report.md`
- `.xagent_runtime/reports/single-tenant-external-delivery-status-report-contract.json`
- `.xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json`
- `.xagent_runtime/reports/single-tenant-external-evidence-collection-pack.md`
- `.xagent_runtime/reports/single-tenant-external-evidence-collection-pack-contract.json`
- `.xagent_runtime/reports/single-tenant-external-execution-receipt.json`
- `.xagent_runtime/reports/single-tenant-external-execution-receipt-contract.json`
- `.xagent_runtime/reports/single-tenant-external-release-claim-aggregation.json`

## Acceptance Criteria

- External unblock plan contract is passed.
- Release-freeze env template contains only empty assignments.
- Strict external release runner succeeds without --plan-only.
- Strict run contract is passed with --require-ready.
- Final handoff artifact index is complete and release_ready=true.
- External delivery receipt records package, handoff index, and strict-run contract hashes with release_ready=true.
- PR/CI evidence manifest contract is passed with --require-ready.
- External upload bundle index contract is passed with --require-ready.
- Readiness execution checklist contract is passed with --require-ready.
- PR/CI upload handoff contract is passed with --require-ready.
- External delivery status report contract is passed with --require-ready.
- External evidence collection pack contract is passed with --require-ready.
- External execution receipt contract is passed with --require-complete.
- External release-claim aggregation is passed with --require-ready.

## Blocker Steps

No external release blockers remain.
## Overall Next Actions

- Run the strict external release runner and archive the delivery receipt, PR/CI manifest, upload bundle index, readiness checklist, PR/CI upload handoff, delivery status report, evidence collection pack, execution receipt, and final handoff artifact index.
