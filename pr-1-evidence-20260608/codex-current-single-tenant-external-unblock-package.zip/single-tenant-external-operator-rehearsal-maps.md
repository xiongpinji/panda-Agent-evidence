# X-Agent Operator Rehearsal Map Fill Guide

- Remote URL map: `.xagent_runtime/reports/single-tenant-external-remote-url-map.json`
- Remote digest map: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
- Digest reference: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.reference.json`
- Map contract: `flat_json_object`
- Remote upload key: `remote_upload`

## Rules
- Keep both map files as flat JSON objects with string values only.
- Use external HTTPS, non-placeholder, credential-free URLs with no sensitive query parameters.
- Fill remote_upload with the external artifact index URL.
- Fill digest values only after observing the remote artifact SHA-256.
- Every observed remote SHA-256 must match the expected SHA-256 from the upload plan.
- Do not paste provider API keys, bearer tokens, signed URLs, cookies, or secrets into maps or notes.

## Upload Artifacts
- `external_unblock_package` path=`.xagent_runtime/reports/single-tenant-external-unblock-package.zip` url_key=`external_unblock_package` digest_key=`external_unblock_package` expected_sha256=`2cdd7c46d54cd6ab832b9d6727f582474080f014304b53b17019e766739a6092`
- `external_unblock_package_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-report.json` url_key=`external_unblock_package_report` digest_key=`external_unblock_package_report` expected_sha256=`14cff5b9dd1da5a672a2a608afeae8aef3401711ab76d5f1fffa1d8160e59b56`
- `external_unblock_package_verify_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json` url_key=`external_unblock_package_verify_report` digest_key=`external_unblock_package_verify_report` expected_sha256=`8de006c83006267b87b8a64ec2376a814673387bad528846f1558dc8ee1ab424`
- `external_handoff_artifact_index` path=`.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json` url_key=`external_handoff_artifact_index` digest_key=`external_handoff_artifact_index` expected_sha256=`6fa3fe2c6994e780c0f058ac7be5643780b6e1450e633f3dec71dd8b14753a38`
- `external_release_strict_run_contract` path=`.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json` url_key=`external_release_strict_run_contract` digest_key=`external_release_strict_run_contract` expected_sha256=`d1782b6e3f3eade76f47ddac570785758db305bf2f44b67faadc346b949b3b50`
- `external_delivery_receipt` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt.json` url_key=`external_delivery_receipt` digest_key=`external_delivery_receipt` expected_sha256=`6165a45190c36755f665e5b3801576f45181355f1123afc16770ee7a376c0c1c`
- `external_delivery_receipt_contract` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json` url_key=`external_delivery_receipt_contract` digest_key=`external_delivery_receipt_contract` expected_sha256=`d0d21cb25c7a37f2589958f882fafa2a5917b186739c389fd4ef556565ef6d80`
- `external_pr_ci_evidence_manifest` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json` url_key=`external_pr_ci_evidence_manifest` digest_key=`external_pr_ci_evidence_manifest` expected_sha256=`e75bb8a7815c81097c23628ce128e6d6a6eb020d5061a73e40c52512347f6121`
- `external_pr_ci_evidence_manifest_contract` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json` url_key=`external_pr_ci_evidence_manifest_contract` digest_key=`external_pr_ci_evidence_manifest_contract` expected_sha256=`27eb2ebdb9125bbfe94d83bc046743796534ac3e88b0c13a240c85f5846ab61d`
- `desktop_suite_current_full_package` path=`.xagent_runtime/reports/desktop-suite-current-full.zip` url_key=`desktop_suite_current_full_package` digest_key=`desktop_suite_current_full_package` expected_sha256=`7fa2bc2d88ea2171974d41f52e9312b76c5a7c14e328983fc7a51d1505238d62`
- `desktop_suite_package_budget` path=`.xagent_runtime/reports/desktop-suite-package-budget.json` url_key=`desktop_suite_package_budget` digest_key=`desktop_suite_package_budget` expected_sha256=`c45a7267d08bdbdd60f0a7f85277581030540ea7693f4f2bc789f9a674c30425`

## Commands
- Map check: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
- Strict gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --assist-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-assist.json --contract-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-contract.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json`

## Flat JSON Shape
```json
{
  "upload_plan_artifact_id": "https://example.com/external-artifact-url",
  "remote_upload": "https://example.com/external-artifact-index"
}
```
