# X-Agent Operator Rehearsal Map Fill Guide

- Remote URL map: `.xagent_runtime/reports/single-tenant-external-remote-url-map.json`
- Remote digest map: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
- Digest reference: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.reference.json`
- Map contract: `flat_json_object`
- Remote upload key: `remote_upload`

## Rules
- Keep both map files as flat JSON objects with string values only.
- Use external HTTPS, non-placeholder, credential-free URLs with no sensitive query parameters.
- Fill remote_upload with the external artifact index URL.
- Fill digest values only after observing the remote artifact SHA-256.
- Every observed remote SHA-256 must match the expected SHA-256 from the upload plan.
- Do not paste provider API keys, bearer tokens, signed URLs, cookies, or secrets into maps or notes.

## Upload Artifacts
- `external_unblock_package` path=`.xagent_runtime/reports/single-tenant-external-unblock-package.zip` url_key=`external_unblock_package` digest_key=`external_unblock_package` expected_sha256=`114745f341cf0ad55ec7b774dfddbae8fea0d44caa416427b990adf67d72e7c7`
- `external_unblock_package_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-report.json` url_key=`external_unblock_package_report` digest_key=`external_unblock_package_report` expected_sha256=`4df002d3060a03fbf43a6fa5e8088f66fc26d18a34976b4eaabe4b374791a400`
- `external_unblock_package_verify_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json` url_key=`external_unblock_package_verify_report` digest_key=`external_unblock_package_verify_report` expected_sha256=`505d3cc240f6efa1e9f61a2b8a9020d6fc172863255ccff05f0febc0cb5d2320`
- `external_handoff_artifact_index` path=`.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json` url_key=`external_handoff_artifact_index` digest_key=`external_handoff_artifact_index` expected_sha256=`92d44afe9ada781d6008372f7a5a03d477372f3c57bd50676324ccff9bce3dad`
- `external_release_strict_run_contract` path=`.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json` url_key=`external_release_strict_run_contract` digest_key=`external_release_strict_run_contract` expected_sha256=`ed3ea7af3f2618b24cd7c9c7714d5d760d561fa3a3105b87053abfbfb7ef284a`
- `external_delivery_receipt` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt.json` url_key=`external_delivery_receipt` digest_key=`external_delivery_receipt` expected_sha256=`5cfb8142a35ea0fc3735f219e2e764d5feada73fb1fabc7410475a86982a49dd`
- `external_delivery_receipt_contract` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json` url_key=`external_delivery_receipt_contract` digest_key=`external_delivery_receipt_contract` expected_sha256=`ec31dae620eee571ab307047b80092b39b8c7b4322b746a0d4f3088bb06c2514`
- `external_pr_ci_evidence_manifest` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json` url_key=`external_pr_ci_evidence_manifest` digest_key=`external_pr_ci_evidence_manifest` expected_sha256=`f085649e25291a049b699516d589a5dd1d7ae26d494f3c2d7a9a483bd8585741`
- `external_pr_ci_evidence_manifest_contract` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json` url_key=`external_pr_ci_evidence_manifest_contract` digest_key=`external_pr_ci_evidence_manifest_contract` expected_sha256=`24b93c6f6bf0277b8a176e10706997a47741309f55f909fc6a328f892ae7bb10`
- `desktop_suite_current_full_package` path=`.xagent_runtime/reports/desktop-suite-current-full.zip` url_key=`desktop_suite_current_full_package` digest_key=`desktop_suite_current_full_package` expected_sha256=`7fa2bc2d88ea2171974d41f52e9312b76c5a7c14e328983fc7a51d1505238d62`
- `desktop_suite_package_budget` path=`.xagent_runtime/reports/desktop-suite-package-budget.json` url_key=`desktop_suite_package_budget` digest_key=`desktop_suite_package_budget` expected_sha256=`c45a7267d08bdbdd60f0a7f85277581030540ea7693f4f2bc789f9a674c30425`

## Commands
- Map check: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
- Strict gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --assist-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-assist.json --contract-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-contract.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json`

## Flat JSON Shape
```json
{
  "upload_plan_artifact_id": "https://example.com/external-artifact-url",
  "remote_upload": "https://example.com/external-artifact-index"
}
```
