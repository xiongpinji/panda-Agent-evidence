# X-Agent Operator Rehearsal Map Fill Guide

- Remote URL map: `.xagent_runtime/reports/single-tenant-external-remote-url-map.json`
- Remote digest map: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
- Digest reference: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.reference.json`
- Map contract: `flat_json_object`
- Remote upload key: `remote_upload`

## Rules
- Keep both map files as flat JSON objects with string values only.
- Use external HTTPS, non-placeholder, credential-free URLs with no sensitive query parameters.
- Fill remote_upload with the external artifact index URL.
- Fill digest values only after observing the remote artifact SHA-256.
- Every observed remote SHA-256 must match the expected SHA-256 from the upload plan.
- Do not paste provider API keys, bearer tokens, signed URLs, cookies, or secrets into maps or notes.

## Upload Artifacts
- `external_unblock_package` path=`.xagent_runtime/reports/single-tenant-external-unblock-package.zip` url_key=`external_unblock_package` digest_key=`external_unblock_package` expected_sha256=`4aa208ef38f649ab06deb30a2e0cefbe521e9dd82cbf13372bdd3d3168153bcc`
- `external_unblock_package_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-report.json` url_key=`external_unblock_package_report` digest_key=`external_unblock_package_report` expected_sha256=`4ed9345e4697f2ffea63cf713a737149de497634bd8fdc52e963601bd00c144c`
- `external_unblock_package_verify_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json` url_key=`external_unblock_package_verify_report` digest_key=`external_unblock_package_verify_report` expected_sha256=`e6e4f347b9ee80acd02aa7d772d784dbbeed3e9b280528bd13cd8b460f180cd1`
- `external_handoff_artifact_index` path=`.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json` url_key=`external_handoff_artifact_index` digest_key=`external_handoff_artifact_index` expected_sha256=`f8f73d0e3867a7e1c4395532d5d9a987677dc1855402045fdbaf2dfd87dc789f`
- `external_release_strict_run_contract` path=`.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json` url_key=`external_release_strict_run_contract` digest_key=`external_release_strict_run_contract` expected_sha256=`49148dd4710e6a23ad41c65080764a02f3fe5e9c275d676a13a5e3862fad71bb`
- `external_delivery_receipt` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt.json` url_key=`external_delivery_receipt` digest_key=`external_delivery_receipt` expected_sha256=`0dfc1cf7e4973753d3da1944c188c43784ddcc243980a817c4980eab1fda1e88`
- `external_delivery_receipt_contract` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json` url_key=`external_delivery_receipt_contract` digest_key=`external_delivery_receipt_contract` expected_sha256=`6087569739051c26e7f3182137cd9bcfe39a0d57c0aa3899272fc90271c5deed`
- `external_pr_ci_evidence_manifest` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json` url_key=`external_pr_ci_evidence_manifest` digest_key=`external_pr_ci_evidence_manifest` expected_sha256=`872b5e05c07db26c4506f44ee89321a9f29d7dec9a44996cf2c2d5642d37cb0f`
- `external_pr_ci_evidence_manifest_contract` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json` url_key=`external_pr_ci_evidence_manifest_contract` digest_key=`external_pr_ci_evidence_manifest_contract` expected_sha256=`138ae2f6187ca2bee179239b84a946e83f9e6edf8c318ffc763136b20b65ca40`
- `desktop_suite_current_full_package` path=`.xagent_runtime/reports/desktop-suite-current-full.zip` url_key=`desktop_suite_current_full_package` digest_key=`desktop_suite_current_full_package` expected_sha256=`7fa2bc2d88ea2171974d41f52e9312b76c5a7c14e328983fc7a51d1505238d62`
- `desktop_suite_package_budget` path=`.xagent_runtime/reports/desktop-suite-package-budget.json` url_key=`desktop_suite_package_budget` digest_key=`desktop_suite_package_budget` expected_sha256=`c45a7267d08bdbdd60f0a7f85277581030540ea7693f4f2bc789f9a674c30425`

## Commands
- Map check: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
- Strict gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --assist-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-assist.json --contract-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-contract.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json`

## Flat JSON Shape
```json
{
  "upload_plan_artifact_id": "https://example.com/external-artifact-url",
  "remote_upload": "https://example.com/external-artifact-index"
}
```
