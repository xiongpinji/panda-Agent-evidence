# X-Agent Operator Rehearsal Map Fill Guide

- Remote URL map: `.xagent_runtime/reports/single-tenant-external-remote-url-map.json`
- Remote digest map: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
- Digest reference: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.reference.json`
- Map contract: `flat_json_object`
- Remote upload key: `remote_upload`

## Rules
- Keep both map files as flat JSON objects with string values only.
- Use external HTTPS, non-placeholder, credential-free URLs with no sensitive query parameters.
- Fill remote_upload with the external artifact index URL.
- Fill digest values only after observing the remote artifact SHA-256.
- Every observed remote SHA-256 must match the expected SHA-256 from the upload plan.
- Do not paste provider API keys, bearer tokens, signed URLs, cookies, or secrets into maps or notes.

## Upload Artifacts
- `external_unblock_package` path=`.xagent_runtime/reports/single-tenant-external-unblock-package.zip` url_key=`external_unblock_package` digest_key=`external_unblock_package` expected_sha256=`101bb1bd28eaa3f96031fbd9950a82839d78f7b9b008af6878d4d526e492c3cf`
- `external_unblock_package_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-report.json` url_key=`external_unblock_package_report` digest_key=`external_unblock_package_report` expected_sha256=`e078fc3b900a9b7bc9a301654f0b09e5a51b52eb4947a7b63f74fc298aaff99a`
- `external_unblock_package_verify_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json` url_key=`external_unblock_package_verify_report` digest_key=`external_unblock_package_verify_report` expected_sha256=`2fcb961bae745c53f806c605b14b385973cacc4f2f56ba6e40bf3e3cf93b3b50`
- `external_handoff_artifact_index` path=`.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json` url_key=`external_handoff_artifact_index` digest_key=`external_handoff_artifact_index` expected_sha256=`1b231bd1dd3cb9040a6bfc05a9156a92d17c6d9151c0276ce5925611504be7f9`
- `external_release_strict_run_contract` path=`.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json` url_key=`external_release_strict_run_contract` digest_key=`external_release_strict_run_contract` expected_sha256=`ed3ea7af3f2618b24cd7c9c7714d5d760d561fa3a3105b87053abfbfb7ef284a`
- `external_delivery_receipt` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt.json` url_key=`external_delivery_receipt` digest_key=`external_delivery_receipt` expected_sha256=`8fb9219bb269282e0e3a078ca4521ae2360026460b85a3972d3b638afb3b398d`
- `external_delivery_receipt_contract` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json` url_key=`external_delivery_receipt_contract` digest_key=`external_delivery_receipt_contract` expected_sha256=`0f99d2bf57b67bbd6ee42c2845d9b4dcc37f6613645114beeb20905ab480a169`
- `external_pr_ci_evidence_manifest` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json` url_key=`external_pr_ci_evidence_manifest` digest_key=`external_pr_ci_evidence_manifest` expected_sha256=`5337ecf87dae74e4fdc79887b3140c7bc17ebe63a3c19c922c0db88602532871`
- `external_pr_ci_evidence_manifest_contract` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json` url_key=`external_pr_ci_evidence_manifest_contract` digest_key=`external_pr_ci_evidence_manifest_contract` expected_sha256=`c65327b008c2a807c898ac4f944b4b3e85a59a110935162f1602e892c4a6fa3f`
- `desktop_suite_current_full_package` path=`.xagent_runtime/reports/desktop-suite-current-full.zip` url_key=`desktop_suite_current_full_package` digest_key=`desktop_suite_current_full_package` expected_sha256=`7fa2bc2d88ea2171974d41f52e9312b76c5a7c14e328983fc7a51d1505238d62`
- `desktop_suite_package_budget` path=`.xagent_runtime/reports/desktop-suite-package-budget.json` url_key=`desktop_suite_package_budget` digest_key=`desktop_suite_package_budget` expected_sha256=`c45a7267d08bdbdd60f0a7f85277581030540ea7693f4f2bc789f9a674c30425`

## Commands
- Map check: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
- Strict gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --assist-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-assist.json --contract-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-contract.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json`

## Flat JSON Shape
```json
{
  "upload_plan_artifact_id": "https://example.com/external-artifact-url",
  "remote_upload": "https://example.com/external-artifact-index"
}
```
