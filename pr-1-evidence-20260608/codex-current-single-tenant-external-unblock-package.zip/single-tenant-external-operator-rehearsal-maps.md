# X-Agent Operator Rehearsal Map Fill Guide

- Remote URL map: `.xagent_runtime/reports/single-tenant-external-remote-url-map.json`
- Remote digest map: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.json`
- Digest reference: `.xagent_runtime/reports/single-tenant-external-remote-digest-map.reference.json`
- Map contract: `flat_json_object`
- Remote upload key: `remote_upload`

## Rules
- Keep both map files as flat JSON objects with string values only.
- Use external HTTPS, non-placeholder, credential-free URLs with no sensitive query parameters.
- Fill remote_upload with the external artifact index URL.
- Fill digest values only after observing the remote artifact SHA-256.
- Every observed remote SHA-256 must match the expected SHA-256 from the upload plan.
- Do not paste provider API keys, bearer tokens, signed URLs, cookies, or secrets into maps or notes.

## Upload Artifacts
- `external_unblock_package` path=`.xagent_runtime/reports/single-tenant-external-unblock-package.zip` url_key=`external_unblock_package` digest_key=`external_unblock_package` expected_sha256=`4b6bd2441365583aaf6347ff43837f5dcf927fd614dccd16e006579fc3adda3b`
- `external_unblock_package_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-report.json` url_key=`external_unblock_package_report` digest_key=`external_unblock_package_report` expected_sha256=`c27d0c89653df6b14e1a6bd0d990553e429f188ee02a876f8f6a0b54aac4e5b3`
- `external_unblock_package_verify_report` path=`.xagent_runtime/reports/single-tenant-external-unblock-package-verify-report.json` url_key=`external_unblock_package_verify_report` digest_key=`external_unblock_package_verify_report` expected_sha256=`049a6cfcdb373e4fcccc4e393ec16b505af6d8144d8ea73c530795176e0c1cd3`
- `external_handoff_artifact_index` path=`.xagent_runtime/reports/single-tenant-external-handoff-artifacts.json` url_key=`external_handoff_artifact_index` digest_key=`external_handoff_artifact_index` expected_sha256=`52884f258489c1ef6fcbaf958df2d6cd09db9e19a739f4b22875fe5b8071f9f5`
- `external_release_strict_run_contract` path=`.xagent_runtime/reports/single-tenant-external-release-strict-run-contract.json` url_key=`external_release_strict_run_contract` digest_key=`external_release_strict_run_contract` expected_sha256=`ed3ea7af3f2618b24cd7c9c7714d5d760d561fa3a3105b87053abfbfb7ef284a`
- `external_delivery_receipt` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt.json` url_key=`external_delivery_receipt` digest_key=`external_delivery_receipt` expected_sha256=`93231b5e15f4d9afc90bb48a01099c27398f177077be427b7ae451adc7b22b6e`
- `external_delivery_receipt_contract` path=`.xagent_runtime/reports/single-tenant-external-delivery-receipt-contract.json` url_key=`external_delivery_receipt_contract` digest_key=`external_delivery_receipt_contract` expected_sha256=`78918e3e7160fd43f2691afb5bba22dccedee498985693149dedbfba77ac82e2`
- `external_pr_ci_evidence_manifest` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest.json` url_key=`external_pr_ci_evidence_manifest` digest_key=`external_pr_ci_evidence_manifest` expected_sha256=`12bf1c3f3f8526f8e80ba4265c28da773f5023f921400b0364481a098cb37501`
- `external_pr_ci_evidence_manifest_contract` path=`.xagent_runtime/reports/single-tenant-external-pr-ci-evidence-manifest-contract.json` url_key=`external_pr_ci_evidence_manifest_contract` digest_key=`external_pr_ci_evidence_manifest_contract` expected_sha256=`1908c17465ccf9cfc57f9c18258fe8a0defcfc62ccc4fe87d6f62debd1c72683`
- `desktop_suite_current_full_package` path=`.xagent_runtime/reports/desktop-suite-current-full.zip` url_key=`desktop_suite_current_full_package` digest_key=`desktop_suite_current_full_package` expected_sha256=`7fa2bc2d88ea2171974d41f52e9312b76c5a7c14e328983fc7a51d1505238d62`
- `desktop_suite_package_budget` path=`.xagent_runtime/reports/desktop-suite-package-budget.json` url_key=`desktop_suite_package_budget` digest_key=`desktop_suite_package_budget` expected_sha256=`c45a7267d08bdbdd60f0a7f85277581030540ea7693f4f2bc789f9a674c30425`

## Commands
- Map check: `python scripts/check_single_tenant_external_operator_rehearsal_maps.py --pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-maps-contract.json`
- Strict gate: `python scripts/run_single_tenant_external_operator_rehearsal_gate.py --receipt .xagent_runtime/reports/single-tenant-external-execution-receipt.json --evidence-pack .xagent_runtime/reports/single-tenant-external-evidence-collection-pack.json --remote-url-map .xagent_runtime/reports/single-tenant-external-remote-url-map.json --remote-digest-map .xagent_runtime/reports/single-tenant-external-remote-digest-map.json --assist-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-assist.json --contract-output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-contract.json --output .xagent_runtime/reports/single-tenant-external-operator-rehearsal-gate.json`

## Flat JSON Shape
```json
{
  "upload_plan_artifact_id": "https://example.com/external-artifact-url",
  "remote_upload": "https://example.com/external-artifact-index"
}
```
